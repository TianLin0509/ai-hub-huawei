"""Small local control adapter. All mutations run on the existing GUI thread.

The booking engine, single-instance lock, browser profile and post-booking actions
remain owned by the secretary. Hub never edits config.json behind the GUI.
"""
import copy
import json
import os
import re
import time
from pathlib import Path
from PyQt5.QtCore import QTimer
from . import config as C

PROTOCOL = 1
FIELDS = ("主题", "开始时间", "时长小时", "时长分钟", "优先会议室", "抢订日")


def validate_patch(patch):
    if not isinstance(patch, dict) or set(patch) - set(FIELDS):
        raise ValueError("只支持主题、时段、优先会议室与每周抢订日；目标日期固定为开放日七天后")
    if "主题" in patch and (not isinstance(patch["主题"], str) or not 1 <= len(patch["主题"].strip()) <= 120):
        raise ValueError("主题须为 1–120 字")
    if "开始时间" in patch and not re.fullmatch(r"(?:[01]\d|2[0-3]):(?:00|30)", str(patch["开始时间"])):
        raise ValueError("开始时间须为整点或半点（HH:00 / HH:30）")
    if "时长小时" in patch and (type(patch["时长小时"]) is not int or not 0 <= patch["时长小时"] <= 12):
        raise ValueError("时长小时须为 0–12")
    if "时长分钟" in patch and patch["时长分钟"] not in (0, 30):
        raise ValueError("时长分钟只支持 0 或 30")
    if "优先会议室" in patch and (not isinstance(patch["优先会议室"], list) or not 1 <= len(patch["优先会议室"]) <= 30
                                 or any(not isinstance(r, str) or not r.strip() or len(r) > 120 for r in patch["优先会议室"])):
        raise ValueError("请填写 1–30 个优先会议室")
    if "抢订日" in patch and (not isinstance(patch["抢订日"], list) or not patch["抢订日"]
                             or any(type(d) is not int or d not in range(1, 8) for d in patch["抢订日"])):
        raise ValueError("抢订日须为 1–7 的星期列表")
    return copy.deepcopy(patch)


class HubControl:
    def __init__(self, window):
        self.w = window
        self.root = Path(C.path("hub-control"))
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "requests").mkdir(exist_ok=True)
        (self.root / "replies").mkdir(exist_ok=True)
        self.last_written = 0
        self.last_state = None
        self.timer = QTimer(window)
        self.timer.timeout.connect(self.tick)
        self.timer.start(1000)
        self.tick()

    def write(self, file, data):
        temp = file.with_suffix(".tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        os.replace(temp, file)

    def status(self):
        w = self.w
        return {"ok": True, "protocol": PROTOCOL, "pid": os.getpid(), "version": C.VERSION,
                "home": C.app_dir(), "running": w._busy(), "mode": w.job,
                "loginNeeded": w.login_state is False, "loginBusy": not w.btn_login.isEnabled(),
                "rules": {k: copy.deepcopy(w.cfg[k]) for k in FIELDS},
                "phases": dict(w.phases), "targetOffsetDays": 7,
                "nextOpen": w.next_open.isoformat() if w.next_open else None}

    def invoke(self, op, args):
        w = self.w
        if op == "status":
            return self.status()
        if op == "configure":
            if w._busy() or not w.btn_login.isEnabled():
                raise ValueError("秘书正在执行任务；请先暂停，待浏览器退出后再改规则")
            patch = validate_patch(args)
            candidate = {**w.cfg, **patch}
            duration = candidate["时长小时"] * 60 + candidate["时长分钟"]
            h, m = map(int, candidate["开始时间"].split(":"))
            if not 30 <= duration <= 720 or h * 60 + m + duration > 24 * 60:
                raise ValueError("会议时长须为 30 分钟至 12 小时，结束时间不能跨天")
            # Persist first; a failed write must not leave the running GUI on new rules.
            C.save_config(candidate)
            w.cfg = candidate
            w._loading = True
            try:
                w._load_into_ui()
            finally:
                w._loading = False
            w.refresh_all()
        elif op in ("start", "test"):
            if w._busy() or not w.btn_login.isEnabled():
                raise ValueError("秘书已有任务在执行，不会重复启动")
            if not w.cfg["优先会议室"]:
                raise ValueError("请先填写优先会议室")
            w.start_job("daemon" if op == "start" else "test")
        elif op == "pause":
            w.stop_job()
        elif op == "login":
            if w._busy() or not w.btn_login.isEnabled():
                raise ValueError("请先暂停任务，待浏览器退出后再登录")
            w.do_login()
        elif op == "show":
            w.show_window()
        else:
            raise ValueError("不支持的秘书控制操作")
        return self.status()

    def tick(self):
        try:
            now = time.time()
            for file in list((self.root / "requests").glob("*.json"))[:10]:
                rid = file.stem
                if not re.fullmatch(r"[a-f0-9-]{36}", rid):
                    continue
                reply = self.root / "replies" / file.name
                if reply.exists():
                    file.unlink()
                    continue
                try:
                    if file.stat().st_size > 32768:
                        raise ValueError("控制请求过大")
                    req = json.loads(file.read_text(encoding="utf-8"))
                    if req.get("id") != rid or abs(now * 1000 - req.get("at", 0)) > 30000:
                        raise ValueError("控制请求已过期，没有执行")
                    result = self.invoke(req.get("op"), req.get("args", {}))
                except Exception as exc:
                    result = {"ok": False, "error": str(exc)}
                self.write(reply, {**result, "requestId": rid, "at": int(now * 1000)})
                file.unlink()
            state = self.status()
            encoded = json.dumps(state, ensure_ascii=False, sort_keys=True)
            if encoded != self.last_state or now - self.last_written >= 10:
                self.write(self.root / "status.json", {**state, "at": int(now * 1000)})
                self.last_state, self.last_written = encoded, now
            # Only this adapter's completed, old reply files are removed.
            for file in (self.root / "replies").glob("*.json"):
                if re.fullmatch(r"[a-f0-9-]{36}", file.stem) and now - file.stat().st_mtime > 86400:
                    file.unlink()
        except Exception as exc:
            self.w.log("Hub 控制入口暂不可用：" + str(exc), "bad")


def attach(window):
    if not getattr(window, "_hub_control", None):
        window._hub_control = HubControl(window)
    return window._hub_control
