"""界面：左侧栏切换的工作台（浅灰底、单一蓝色强调）。"""
import os
import threading
import time
from datetime import datetime, timedelta

from PyQt5.QtCore import QObject, Qt, QTimer, pyqtSignal, QTime, QRectF
from PyQt5.QtGui import QColor, QFont, QIcon, QPainter, QPixmap, QPalette, QTextCursor, QDesktopServices
from PyQt5.QtWidgets import (
    QAbstractItemView, QAbstractSpinBox, QApplication, QButtonGroup, QCheckBox, QComboBox, QFrame, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu, QPushButton,
    QRadioButton, QScrollArea, QSizePolicy, QSpinBox, QStackedWidget, QSystemTrayIcon, QTableWidget,
    QTableWidgetItem, QTextEdit, QTimeEdit, QVBoxLayout, QWidget, QDialog, QDialogButtonBox,
)
from PyQt5.QtCore import QUrl

from . import config as C
from . import post, share, system, update, welink
from .clock import Clock
from .engine import interactive_login, read_rooms
from .jobs import Runner
from .update_ui import UpdateController

ACC, ACC_BG, ACC_INK = "#3478f6", "#eaf1fe", "#1f5fd6"
OK, OK_BG = "#15803d", "#effaf3"
WARN, WARN_BG = "#b45309", "#fdf3e7"
BAD, BAD_BG = "#c2362b", "#fdecea"
INK, INK2, MUTE, FAINT, LINE = "#1c1c1e", "#2c2c30", "#6c6c72", "#9a9aa0", "#e4e4ea"
WD = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]

QSS = f"""
* {{ font-family: "Microsoft YaHei UI", "Microsoft YaHei"; }}
QWidget {{ font-size: 14px; color: {INK2}; }}
QMainWindow, #Main, #Page {{ background: #f8f8fa; }}
#Side {{ background: #ededf1; }}
#Brand {{ font-size: 15px; font-weight: 700; color: {INK}; }}
#BrandSub, #Section, #Ver {{ font-size: 12px; color: {FAINT}; }}
QListWidget#Nav {{ background: transparent; border: none; outline: 0; }}
QListWidget#Nav::item {{ height: 38px; padding-left: 12px; border-radius: 8px; margin: 1px 0; color: {INK2}; }}
QListWidget#Nav::item:selected {{ background: {ACC}; color: #ffffff; }}
QListWidget#Nav::item:hover:!selected {{ background: #e2e2e8; }}
QScrollArea {{ border: none; background: transparent; }}
#Crumb {{ color: {MUTE}; font-size: 13px; }}
#Pill {{ border: 1px solid {LINE}; border-radius: 11px; padding: 2px 10px; color: {MUTE}; font-size: 12px; background: #fff; }}
#H1 {{ font-size: 24px; font-weight: 700; color: {INK}; }}
#Sub {{ color: {MUTE}; font-size: 14px; }}
QFrame[cls="block"] {{ background: #ffffff; border: 1px solid #e9e9ee; border-radius: 14px; }}
#BlockTitle {{ font-size: 15px; font-weight: 700; color: {INK}; }}
#StatLabel {{ color: {MUTE}; font-size: 13px; }}
#StatValue {{ font-size: 26px; font-weight: 700; color: {INK}; font-family: "Segoe UI", "Microsoft YaHei UI"; }}
#StatNote {{ color: {FAINT}; font-size: 12px; }}
#Help {{ color: {FAINT}; font-size: 12px; }}
#FieldLabel {{ color: {MUTE}; font-size: 13px; }}
#Saved {{ color: {FAINT}; font-size: 12px; }}
QPushButton {{ background: #fff; border: 1px solid #dcdce3; border-radius: 8px; padding: 7px 16px; color: {INK2}; }}
QPushButton:hover {{ background: #f3f3f6; }}
QPushButton:disabled {{ color: #b4b4ba; background: #f6f6f8; border-color: #ececf0; }}
QPushButton#Primary {{ background: {ACC}; color: #fff; border: 1px solid {ACC}; font-weight: 700; }}
QPushButton#Primary:hover {{ background: #2a6ae8; }}
QPushButton#Primary:disabled {{ background: #a9c6fb; border-color: #a9c6fb; color: #fff; }}
QPushButton[cls="day"] {{ min-width: 54px; padding: 6px 0; }}
QPushButton[cls="day"]:checked {{ background: {ACC_BG}; color: {ACC_INK}; border-color: {ACC}; font-weight: 700; }}
QPushButton[cls="link"] {{ border: none; background: transparent; color: {ACC}; padding: 4px 6px; }}
QPushButton[cls="link"]:hover {{ color: {ACC_INK}; text-decoration: underline; }}
QLineEdit, QSpinBox, QComboBox, QTimeEdit {{ background: #fff; border: 1px solid #dcdce3; border-radius: 8px; padding: 5px 10px; min-height: 24px; selection-background-color: {ACC}; }}
QLineEdit:focus, QSpinBox:focus, QComboBox:focus, QTimeEdit:focus {{ border-color: {ACC}; }}
QComboBox::drop-down {{ border: none; width: 24px; }}
QComboBox QAbstractItemView {{ border: 1px solid {LINE}; background: #fff; selection-background-color: {ACC_BG}; selection-color: {ACC_INK}; outline: 0; }}
QListWidget#Rooms {{ background: #fff; border: 1px solid #dcdce3; border-radius: 8px; padding: 4px; outline: 0; }}
QListWidget#Rooms::item {{ height: 34px; padding-left: 8px; border-radius: 6px; }}
QListWidget#Rooms::item:selected {{ background: {ACC_BG}; color: {ACC_INK}; }}
QListWidget#Plain {{ background: transparent; border: none; outline: 0; }}
QListWidget#Plain::item {{ padding: 6px 2px; border-bottom: 1px solid #efeff3; }}
QListWidget#Plain::item:selected {{ background: {ACC_BG}; color: {ACC_INK}; }}
QTableWidget {{ background: #fff; border: none; gridline-color: #efeff3; font-size: 13px; selection-background-color: {ACC_BG}; selection-color: {INK}; }}
QHeaderView::section {{ background: #fff; color: {FAINT}; border: none; border-bottom: 1px solid {LINE}; padding: 8px 6px; font-size: 12px; }}
QTextEdit#Log {{ background: #fff; border: none; font-family: "Cascadia Mono", Consolas, "Microsoft YaHei UI"; font-size: 13px; }}
#Alert {{ background: {BAD_BG}; border: 1px solid #f3c6c1; border-radius: 10px; }}
#AlertText {{ color: {BAD}; font-size: 14px; }}
QScrollBar:vertical {{ width: 10px; background: transparent; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #d6d6dc; border-radius: 4px; min-height: 30px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
QPushButton#UpdEntry {{ border: none; background: transparent; text-align: left; padding: 6px 10px; color: {MUTE}; font-size: 13px; border-radius: 8px; }}
QPushButton#UpdEntry:hover {{ background: #e2e2e8; color: {INK}; }}
QPushButton#UpdEntry[hot="true"] {{ color: {ACC_INK}; font-weight: 700; }}
#UpdDot {{ background: {BAD}; border-radius: 4px; }}
QToolTip {{ background: #fff; color: {INK2}; border: 1px solid {LINE}; padding: 6px; }}
"""


def make_icon():
    pm = QPixmap(256, 256)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setBrush(QColor(ACC))
    p.setPen(Qt.NoPen)
    p.drawRoundedRect(QRectF(8, 8, 240, 240), 56, 56)
    p.setPen(QColor("#ffffff"))
    f = QFont("Microsoft YaHei UI", 1)
    f.setPixelSize(150)
    f.setBold(True)
    p.setFont(f)
    p.drawText(QRectF(8, 0, 240, 248), Qt.AlignCenter, "秘")
    p.end()
    return QIcon(pm)


def tone_color(status):
    return {"成功": (OK, OK_BG), "失败": (BAD, BAD_BG), "错误": (BAD, BAD_BG), "满员": (BAD, BAD_BG)}.get(status, (WARN, WARN_BG))


def pill(text, fg, bg):
    lb = QLabel(text)
    lb.setStyleSheet(f"background:{bg}; color:{fg}; border-radius:10px; padding:2px 10px; font-size:12px;")
    lb.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
    return lb


def block(title=None, extra=None):
    f = QFrame()
    f.setProperty("cls", "block")
    lay = QVBoxLayout(f)
    lay.setContentsMargins(20, 18, 20, 18)
    lay.setSpacing(12)
    if title:
        row = QHBoxLayout()
        t = QLabel(title)
        t.setObjectName("BlockTitle")
        row.addWidget(t)
        row.addStretch(1)
        if extra:
            row.addWidget(extra)
        lay.addLayout(row)
    return f, lay


def label(text, name=None, wrap=False):
    lb = QLabel(text)
    if name:
        lb.setObjectName(name)
    lb.setWordWrap(wrap)
    return lb


class Bus(QObject):
    log = pyqtSignal(str, str)
    phase = pyqtSignal(str, str, str)
    result = pyqtSignal(object)
    schedule = pyqtSignal(object, object, bool)
    login_bad = pyqtSignal()
    job_done = pyqtSignal(str)
    login_done = pyqtSignal(bool)
    rooms_read = pyqtSignal(object)


class Page(QScrollArea):
    def __init__(self, crumb, title, sub):
        super().__init__()
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        inner = QWidget()
        inner.setObjectName("Page")
        outer = QHBoxLayout(inner)
        outer.setContentsMargins(40, 22, 40, 32)
        col = QWidget()
        col.setMaximumWidth(1080)
        outer.addWidget(col, 1)
        self.body = QVBoxLayout(col)
        self.body.setContentsMargins(0, 0, 0, 0)
        self.body.setSpacing(16)
        top = QHBoxLayout()
        top.addWidget(label(f"{C.APP_NAME}  /  <b style='color:{INK}'>{crumb}</b>", "Crumb"))
        top.addStretch(1)
        self.top_right = top
        top.addWidget(label(f"v{C.VERSION}", "Pill"))
        self.body.addLayout(top)
        self.body.addSpacing(14)
        self.h1 = label(title, "H1", wrap=True)
        self.sub = label(sub, "Sub", wrap=True)
        self.body.addWidget(self.h1)
        self.body.addWidget(self.sub)
        self.body.addSpacing(6)
        self.setWidget(inner)

    def finish(self):
        self.body.addStretch(1)


def form_row(grid, r, text, widget, help_text=None):
    lb = label(text, "FieldLabel")
    lb.setMinimumWidth(110)
    grid.addWidget(lb, r, 0, Qt.AlignLeft | Qt.AlignVCenter)
    grid.addWidget(widget, r, 1, Qt.AlignLeft | Qt.AlignVCenter)
    if help_text:
        h = label(help_text, "Help", wrap=True)
        h.setMinimumWidth(280)
        grid.addWidget(h, r, 2, Qt.AlignLeft | Qt.AlignVCenter)


class MainWindow(QMainWindow):
    def __init__(self, start_daemon=False, updated_from=None):
        super().__init__()
        self.cfg = C.load_config()
        self.clock = Clock()
        self.bus = Bus()
        self.stop_event = None
        self.job = None  # 当前任务名：daemon / once / test
        self.job_thread = None
        self.next_open = None
        self.next_target = None
        self.login_state = None
        self.login_checked_at = None
        self.phases = {}
        self._loading = True
        self.setWindowTitle(f"{C.APP_NAME} · WeLink 会议室抢订")
        self.icon = make_icon()
        self.setWindowIcon(self.icon)
        self.resize(1240, 800)
        self.setMinimumSize(1060, 700)
        os.makedirs(C.path("logs"), exist_ok=True)

        self.updater = None
        self._build()
        for sb in self.findChildren(QAbstractSpinBox):
            sb.setButtonSymbols(QAbstractSpinBox.NoButtons)
        self._wire()
        self._build_tray()
        self._load_into_ui()
        self._loading = False
        self.refresh_all()

        self.save_timer = QTimer(self, singleShot=True, interval=400, timeout=self._save_now)
        self.tick = QTimer(self, interval=1000, timeout=self._on_tick)
        self.tick.start()
        self.post_timer = QTimer(self, interval=20000, timeout=self._run_post_actions)
        self.post_timer.start()
        QTimer.singleShot(3000, self._run_post_actions)
        self.log(f"{C.APP_NAME} v{C.VERSION} 已启动（程序代码：{update.code_origin()}），数据目录：{C.app_dir()}")
        self.updater = UpdateController(self)
        self.updater.state_changed.connect(self._render_update_entry)
        self._render_update_entry()
        QTimer.singleShot(3000, update.mark_healthy)
        if self.cfg["系统"].get("自动检查更新", True):
            QTimer.singleShot(5000, self.updater.auto_check)
        self.updater.timer.start()
        if updated_from:
            msg = f"已从 v{updated_from} 更新到 v{C.VERSION}" if updated_from != C.VERSION else f"已重新启动（v{C.VERSION}）"
            self.log(msg + "，登录资料、配置和历史都还在", "ok")
            QTimer.singleShot(1200, lambda: self.tray.showMessage(C.APP_NAME, msg, QSystemTrayIcon.Information, 8000))
        if start_daemon:
            QTimer.singleShot(500, self.start_daemon)

    # ================= 搭界面 =================
    def _build(self):
        root = QWidget()
        h = QHBoxLayout(root)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        self.setCentralWidget(root)

        side = QFrame()
        side.setObjectName("Side")
        side.setFixedWidth(248)
        sv = QVBoxLayout(side)
        sv.setContentsMargins(12, 22, 12, 16)
        sv.setSpacing(6)
        brand = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(self.icon.pixmap(30, 30))
        brand.addWidget(logo)
        bt = QVBoxLayout()
        bt.setSpacing(0)
        bt.addWidget(label(C.APP_NAME, "Brand"))
        bt.addWidget(label("WeLink 会议室抢订", "BrandSub"))
        brand.addLayout(bt)
        brand.addStretch(1)
        sv.addLayout(brand)
        sv.addSpacing(22)
        sec = label("工作区", "Section")
        sec.setContentsMargins(10, 0, 0, 4)
        sv.addWidget(sec)
        self.nav = QListWidget()
        self.nav.setObjectName("Nav")
        self.nav.setFocusPolicy(Qt.NoFocus)
        for name in ["总览", "抢订计划", "会后动作", "历史记录", "运行日志", "设置"]:
            self.nav.addItem(QListWidgetItem(name))
        sv.addWidget(self.nav, 1)
        upd = QHBoxLayout()
        upd.setContentsMargins(0, 0, 0, 0)
        upd.setSpacing(0)
        self.upd_btn = QPushButton("软件更新")
        self.upd_btn.setObjectName("UpdEntry")
        self.upd_btn.setCursor(Qt.PointingHandCursor)
        self.upd_btn.clicked.connect(lambda: self.updater and self.updater.open_dialog())
        self.upd_dot = QLabel()
        self.upd_dot.setObjectName("UpdDot")
        self.upd_dot.setFixedSize(8, 8)
        self.upd_dot.hide()
        upd.addWidget(self.upd_btn, 1)
        upd.addWidget(self.upd_dot, 0, Qt.AlignVCenter)
        upd.addSpacing(10)
        sv.addLayout(upd)
        sv.addSpacing(6)
        self.side_status = label("", None)
        self.side_status.setContentsMargins(10, 0, 0, 0)
        sv.addWidget(self.side_status)
        h.addWidget(side)

        self.stack = QStackedWidget()
        self.stack.setObjectName("Main")
        h.addWidget(self.stack, 1)
        for build in (self._page_overview, self._page_plan, self._page_post, self._page_history, self._page_log, self._page_settings):
            self.stack.addWidget(build())
        self.nav.currentRowChanged.connect(self._on_nav)
        self.nav.setCurrentRow(0)

    # ---------- 总览 ----------
    def _page_overview(self):
        pg = Page("总览", "", "")
        self.ov = pg
        # 登录失效提示条
        self.alert = QFrame()
        self.alert.setObjectName("Alert")
        al = QHBoxLayout(self.alert)
        al.setContentsMargins(16, 10, 12, 10)
        self.alert_text = label("", "AlertText", wrap=True)
        al.addWidget(self.alert_text, 1)
        b = QPushButton("打开浏览器登录")
        b.setObjectName("Primary")
        b.clicked.connect(self.do_login)
        al.addWidget(b)
        self.alert.hide()
        pg.body.addWidget(self.alert)

        stats = QHBoxLayout()
        stats.setSpacing(14)
        self.stat = {}
        for key, title in [("count", "距开放"), ("target", "目标日期"), ("login", "登录状态"), ("last", "上次结果")]:
            f, lay = block()
            lay.setSpacing(6)
            lay.addWidget(label(title, "StatLabel"))
            v = label("—", "StatValue")
            n = label("", "StatNote", wrap=True)
            lay.addWidget(v)
            lay.addWidget(n)
            self.stat[key] = (v, n)
            stats.addWidget(f, 1)
        pg.body.addLayout(stats)

        acts = QHBoxLayout()
        acts.setSpacing(10)
        self.btn_daemon = QPushButton("启动守护")
        self.btn_daemon.setObjectName("Primary")
        self.btn_daemon.setToolTip("每天开放时刻自动抢下周同一天；关窗口后在托盘继续运行")
        self.btn_stop = QPushButton("停止")
        self.btn_test = QPushButton("测试填表（不提交）")
        self.btn_test.setToolTip("走一遍填表和选会议室，截图后关闭，不点预定")
        self.btn_once = QPushButton("立即抢一次")
        self.btn_once.setToolTip("现在就准备；没到开放时刻会等到点再提交，已过点则马上提交")
        self.btn_login = QPushButton("登录 / 检查登录")
        for w in (self.btn_daemon, self.btn_stop, self.btn_test, self.btn_once):
            acts.addWidget(w)
        acts.addStretch(1)
        acts.addWidget(self.btn_login)
        pg.body.addLayout(acts)

        two = QHBoxLayout()
        two.setSpacing(14)
        f, lay = block("今天的流程")
        self.flow_rows = {}
        for key, title in [("precheck", "登录预检"), ("prepare", "填表选会议室"), ("submit", "整点提交"), ("post", "会后动作")]:
            row = QHBoxLayout()
            row.setSpacing(10)
            dot = QLabel()
            dot.setFixedSize(10, 10)
            t = label(title)
            t.setMinimumWidth(96)
            t.setStyleSheet(f"font-weight:700; color:{INK};")
            d = label("", "Sub", wrap=True)
            d.setStyleSheet(f"color:{MUTE}; font-size:13px;")
            row.addWidget(dot, 0, Qt.AlignVCenter)
            row.addWidget(t, 0, Qt.AlignVCenter)
            row.addWidget(d, 1)
            lay.addLayout(row)
            self.flow_rows[key] = (dot, d)
        lay.addStretch(1)
        two.addWidget(f, 3)
        link = QPushButton("全部历史")
        link.setProperty("cls", "link")
        link.clicked.connect(lambda: self.nav.setCurrentRow(3))
        f, lay = block("最近 5 次", link)
        self.recent_box = QVBoxLayout()
        self.recent_box.setSpacing(8)
        lay.addLayout(self.recent_box)
        lay.addStretch(1)
        two.addWidget(f, 2)
        pg.body.addLayout(two)
        pg.finish()
        return pg

    # ---------- 抢订计划 ----------
    def _page_plan(self):
        pg = Page("抢订计划", "抢订计划", "每天开放时刻放出下周同一天的会议室，这里定好抢什么。改动自动保存。")
        self.saved_lbl = label("", "Saved")
        pg.top_right.insertWidget(2, self.saved_lbl)

        f, lay = block("会议")
        g = QGridLayout()
        g.setHorizontalSpacing(14)
        g.setVerticalSpacing(12)
        self.ed_topic = QLineEdit()
        self.ed_topic.setMinimumWidth(320)
        form_row(g, 0, "会议主题", self.ed_topic, "会写进 WeLink 的会议主题，也用于会后自动释放时找到这场会")
        self.cb_start = QComboBox()
        self.cb_start.setMinimumWidth(120)
        for i in range(17, 44):
            self.cb_start.addItem(f"{i // 2:02d}:{'30' if i % 2 else '00'}")
        form_row(g, 1, "开始时间", self.cb_start)
        dur = QWidget()
        dl = QHBoxLayout(dur)
        dl.setContentsMargins(0, 0, 0, 0)
        self.sp_hours = QSpinBox()
        self.sp_hours.setRange(0, 12)
        self.sp_hours.setFixedWidth(80)
        self.cb_min = QComboBox()
        self.cb_min.addItems(["00", "30"])
        self.cb_min.setFixedWidth(80)
        dl.addWidget(self.sp_hours)
        dl.addWidget(label("小时"))
        dl.addSpacing(8)
        dl.addWidget(self.cb_min)
        dl.addWidget(label("分钟"))
        self.dur_hint = label("", "Help")
        self.dur_hint.setMinimumWidth(280)
        form_row(g, 2, "时长", dur)
        g.addWidget(self.dur_hint, 2, 2)
        g.setColumnStretch(2, 1)
        lay.addLayout(g)
        pg.body.addWidget(f)

        f, lay = block("哪几天要抢")
        days = QHBoxLayout()
        days.setSpacing(8)
        self.day_btns = []
        for i, n in enumerate(WD):
            b = QPushButton(n)
            b.setProperty("cls", "day")
            b.setCheckable(True)
            days.addWidget(b)
            self.day_btns.append(b)
        days.addStretch(1)
        lay.addLayout(days)
        self.days_hint = label("", "Help", wrap=True)
        lay.addWidget(self.days_hint)
        pg.body.addWidget(f)

        f, lay = block("优先会议室")
        lay.addWidget(label("按从上到下的顺序试，选第一间在该时段全空闲的。可拖动排序，双击改名。", "Help"))
        row = QHBoxLayout()
        self.rooms = QListWidget()
        self.rooms.setObjectName("Rooms")
        self.rooms.setDragDropMode(QAbstractItemView.InternalMove)
        self.rooms.setMinimumHeight(210)
        row.addWidget(self.rooms, 1)
        col = QVBoxLayout()
        self.btn_up = QPushButton("上移")
        self.btn_down = QPushButton("下移")
        self.btn_del = QPushButton("删除")
        for b in (self.btn_up, self.btn_down, self.btn_del):
            col.addWidget(b)
        col.addStretch(1)
        row.addLayout(col)
        lay.addLayout(row)
        add = QHBoxLayout()
        self.ed_room = QLineEdit()
        self.ed_room.setPlaceholderText("会议室全名，需与页面上一字不差；不确定就点右边「从页面读取」")
        self.btn_add = QPushButton("添加")
        self.btn_read_rooms = QPushButton("从页面读取")
        self.btn_read_rooms.setToolTip("打开 WeLink 会议室弹窗，列出你能看到的会议室，勾选后加入（约 20 秒）")
        add.addWidget(self.ed_room, 1)
        add.addWidget(self.btn_add)
        add.addWidget(self.btn_read_rooms)
        lay.addLayout(add)
        self.ck_fallback = QCheckBox("首选在整点被别人抢走时，自动重新打开页面换下一间（约 20–30 秒）")
        lay.addWidget(self.ck_fallback)
        pg.body.addWidget(f)
        pg.finish()
        return pg

    # ---------- 会后动作 ----------
    def _page_post(self):
        pg = Page("会后动作", "会后动作", "抢到会议室以后，在会议开始前后自动做的事。依赖公司内部工具 welink-cli，找不到时只能选「不动作」。")
        f, lay = block("模式")
        self.post_group = QButtonGroup(self)
        descs = {
            "不动作": "抢到就结束。",
            "通知模式": "会议开始前几分钟，用 WeLink 给指定账号发一条提醒，避免没签到被系统自动释放。",
            "自动释放": "会议开始时自动取消这场会，把会议室让出来（适合只是先占着、到时不一定用的情况）。",
        }
        for i, m in enumerate(C.POST_MODES):
            rb = QRadioButton(m)
            rb.setStyleSheet(f"font-weight:700; color:{INK};")
            self.post_group.addButton(rb, i)
            lay.addWidget(rb)
            d = label(descs[m], "Help", wrap=True)
            d.setContentsMargins(26, 0, 0, 6)
            lay.addWidget(d)
        g = QGridLayout()
        g.setHorizontalSpacing(14)
        g.setVerticalSpacing(12)
        self.ed_receiver = QLineEdit()
        self.ed_receiver.setFixedWidth(220)
        form_row(g, 0, "提醒接收人", self.ed_receiver, "WeLink 账号 ID，默认 p_xiaoluban（小鲁班）")
        self.sp_remind = QSpinBox()
        self.sp_remind.setRange(1, 60)
        self.sp_remind.setSuffix(" 分钟")
        self.sp_remind.setFixedWidth(120)
        form_row(g, 1, "提前提醒", self.sp_remind)
        g.setColumnStretch(2, 1)
        lay.addLayout(g)
        pg.body.addWidget(f)

        f, lay = block("welink-cli")
        row = QHBoxLayout()
        self.cli_lbl = label("", None, wrap=True)
        row.addWidget(self.cli_lbl, 1)
        self.btn_cli_test = QPushButton("发一条测试消息")
        row.addWidget(self.btn_cli_test)
        lay.addLayout(row)
        pg.body.addWidget(f)

        f, lay = block("待执行")
        self.pending_list = QListWidget()
        self.pending_list.setObjectName("Plain")
        self.pending_list.setMinimumHeight(120)
        lay.addWidget(self.pending_list)
        row = QHBoxLayout()
        row.addWidget(label("程序关掉再打开也会接着执行；电脑关机错过的提醒会自动作废。", "Help"))
        row.addStretch(1)
        self.btn_pending_del = QPushButton("删除选中")
        row.addWidget(self.btn_pending_del)
        lay.addLayout(row)
        pg.body.addWidget(f)
        pg.finish()
        return pg

    # ---------- 历史 ----------
    def _page_history(self):
        pg = Page("历史记录", "历史记录", "最近 50 次抢订（与旧版 booking_history.json 共用）。")
        f, lay = block()
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["目标日期", "时段", "结果", "会议室", "记录时间", "备注"])
        self.table.verticalHeader().hide()
        self.table.setShowGrid(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setFocusPolicy(Qt.NoFocus)
        hh = self.table.horizontalHeader()
        hh.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        for i, w in enumerate([110, 120, 80, 170, 160]):
            self.table.setColumnWidth(i, w)
        hh.setStretchLastSection(True)
        self.table.verticalHeader().setDefaultSectionSize(38)
        self.table.setMinimumHeight(460)
        lay.addWidget(self.table)
        row = QHBoxLayout()
        row.addStretch(1)
        b = QPushButton("打开截图文件夹")
        b.clicked.connect(lambda: self._open_dir("screenshots"))
        row.addWidget(b)
        lay.addLayout(row)
        pg.body.addWidget(f)
        pg.finish()
        return pg

    # ---------- 日志 ----------
    def _page_log(self):
        pg = Page("运行日志", "运行日志", "每一步做了什么、为什么。同时写进 logs 文件夹，按天一个文件。")
        f, lay = block()
        self.log_view = QTextEdit()
        self.log_view.setObjectName("Log")
        self.log_view.setReadOnly(True)
        self.log_view.setMinimumHeight(480)
        lay.addWidget(self.log_view)
        row = QHBoxLayout()
        row.addStretch(1)
        b = QPushButton("清空显示")
        b.clicked.connect(self.log_view.clear)
        row.addWidget(b)
        b = QPushButton("打开日志文件夹")
        b.clicked.connect(lambda: self._open_dir("logs"))
        row.addWidget(b)
        lay.addLayout(row)
        pg.body.addWidget(f)
        pg.finish()
        return pg

    # ---------- 设置 ----------
    def _page_settings(self):
        pg = Page("设置", "设置", "默认值就能用；页面改版或抢不准时再来调。改动自动保存，下一轮生效。")
        f, lay = block("抢订节奏")
        g = QGridLayout()
        g.setHorizontalSpacing(14)
        g.setVerticalSpacing(12)
        self.te_open = QTimeEdit()
        self.te_open.setDisplayFormat("HH:mm:ss")
        self.te_open.setFixedWidth(130)
        form_row(g, 0, "开放时间", self.te_open, "WeLink 放出下周会议室的时刻")
        self.sp_lead = QSpinBox()
        self.sp_lead.setRange(5, 600)
        self.sp_lead.setSuffix(" 秒")
        self.sp_lead.setFixedWidth(130)
        self.lead_hint = label("", "Help", wrap=True)
        self.lead_hint.setMinimumWidth(280)
        form_row(g, 1, "提前填表", self.sp_lead)
        g.addWidget(self.lead_hint, 1, 2)
        self.sp_retry = QSpinBox()
        self.sp_retry.setRange(1, 30)
        self.sp_retry.setSuffix(" 次")
        self.sp_retry.setFixedWidth(130)
        form_row(g, 2, "整点连点", self.sp_retry, "到点后最多点几次「预定」")
        self.sp_interval = QSpinBox()
        self.sp_interval.setRange(50, 3000)
        self.sp_interval.setSingleStep(50)
        self.sp_interval.setSuffix(" 毫秒")
        self.sp_interval.setFixedWidth(130)
        form_row(g, 3, "连点间隔", self.sp_interval, "每次点完先等 0.5 秒看结果，再隔这么久点下一次")
        self.sp_pre = QSpinBox()
        self.sp_pre.setRange(0, 180)
        self.sp_pre.setSuffix(" 分钟")
        self.sp_pre.setFixedWidth(130)
        form_row(g, 4, "登录预检", self.sp_pre, "开放前多久先检查一次登录；失效会弹窗并发消息提醒，给你时间重新登录。0 = 不检查")
        self.ck_clock = QCheckBox("按 WeLink 服务器时间对齐整点")
        self.clock_lbl = label("", "Help", wrap=True)
        self.clock_lbl.setMinimumWidth(280)
        form_row(g, 5, "时间校准", self.ck_clock)
        g.addWidget(self.clock_lbl, 5, 2)
        g.setColumnStretch(2, 1)
        lay.addLayout(g)
        pg.body.addWidget(f)

        f, lay = block("电脑")
        self.ck_awake = QCheckBox("守护期间不让电脑自动睡眠（合上笔记本盖子仍会睡）")
        self.ck_autostart = QCheckBox("开机后自动启动并进入守护（Windows 更新重启后不会漏抢）")
        lay.addWidget(self.ck_awake)
        lay.addWidget(self.ck_autostart)
        pg.body.addWidget(f)

        f, lay = block("页面适配")
        lay.addWidget(label("WeLink 页面改版后才需要动这里。先点总览里的「测试填表」，看日志和截图再决定。", "Help", wrap=True))
        g = QGridLayout()
        g.setHorizontalSpacing(14)
        g.setVerticalSpacing(12)
        self.ed_url = QLineEdit()
        self.ed_url.setMinimumWidth(420)
        form_row(g, 0, "预定页地址", self.ed_url)
        self.ck_calib = QCheckBox("自动标定时间网格（按页面上格子的实际位置计算）")
        form_row(g, 1, "网格标定", self.ck_calib)
        grid = QWidget()
        gl = QHBoxLayout(grid)
        gl.setContentsMargins(0, 0, 0, 0)
        self.sp_gx = QSpinBox()
        self.sp_gx.setRange(0, 3000)
        self.sp_gx.setFixedWidth(90)
        self.sp_gw = QSpinBox()
        self.sp_gw.setRange(10, 100)
        self.sp_gw.setFixedWidth(80)
        self.te_gs = QTimeEdit()
        self.te_gs.setDisplayFormat("HH:mm")
        self.te_gs.setFixedWidth(90)
        for t, w in (("起点 X", self.sp_gx), ("格宽", self.sp_gw), ("首格时间", self.te_gs)):
            gl.addWidget(label(t, "FieldLabel"))
            gl.addWidget(w)
            gl.addSpacing(8)
        form_row(g, 2, "手动标定值", grid, "自动标定失败时才用；旧版是 472 / 30 / 08:30")
        self.cb_browser = QComboBox()
        self.cb_browser.addItems(["自动", "Edge", "Chrome", "内置Chromium"])
        self.cb_browser.setFixedWidth(150)
        form_row(g, 3, "浏览器", self.cb_browser, "自动 = 依次试 Edge、Chrome")
        self.ed_cli = QLineEdit()
        self.ed_cli.setPlaceholderText("留空则自动查找")
        self.ed_cli.setMinimumWidth(420)
        form_row(g, 4, "welink-cli 路径", self.ed_cli)
        g.setColumnStretch(2, 1)
        lay.addLayout(g)
        pg.body.addWidget(f)
        f, lay = block("软件更新与分享")
        row = QHBoxLayout()
        self.ver_lbl = label("", None, wrap=True)
        row.addWidget(self.ver_lbl, 1)
        b = QPushButton("检查更新")
        b.clicked.connect(lambda: self.updater and self.updater.open_dialog())
        row.addWidget(b)
        lay.addLayout(row)
        self.ck_autoupd = QCheckBox("启动后自动检查更新，之后每 6 小时查一次（有新版本只提醒，不会自己重启）")
        lay.addWidget(self.ck_autoupd)
        lay.addWidget(label("更新源：GitHub 优先，连不上或被拦截时自动换备用服务器（阿里云）。只接受发布者签名过的更新；"
                            "平时只换程序代码（几十 KB），运行环境变了才换整个程序。", "Help", wrap=True))
        sep = QFrame()
        sep.setFixedHeight(1)
        sep.setStyleSheet(f"background:{LINE};")
        lay.addWidget(sep)
        row = QHBoxLayout()
        row.addWidget(label("分享给同事：只打包程序本身和一页使用说明，不含你的登录资料、配置、历史和截图。"
                            "同事第一次打开要自己登录、添加自己的会议室。", "Help", wrap=True), 1)
        self.btn_share = QPushButton("生成分享包")
        self.btn_share.clicked.connect(self._make_share)
        row.addWidget(self.btn_share)
        lay.addLayout(row)
        pg.body.addWidget(f)
        dir_row = QHBoxLayout()
        dir_row.addWidget(label(f"数据目录：{C.app_dir()}（配置、历史、登录资料都在这里）", "Help"))
        dir_row.addStretch(1)
        b = QPushButton("打开数据目录")
        b.clicked.connect(lambda: self._open_dir(""))
        dir_row.addWidget(b)
        pg.body.addLayout(dir_row)
        pg.finish()
        return pg

    def _build_tray(self):
        self.tray = QSystemTrayIcon(self.icon, self)
        self.tray.setToolTip(C.APP_NAME)
        m = QMenu()
        m.addAction("打开主界面", self.show_window)
        self.act_daemon = m.addAction("启动守护", self.start_daemon)
        self.act_stop = m.addAction("停止", self.stop_job)
        m.addSeparator()
        m.addAction("退出", self.quit_app)
        self.tray.setContextMenu(m)
        self.tray.activated.connect(lambda r: self.show_window() if r in (QSystemTrayIcon.DoubleClick, QSystemTrayIcon.Trigger) else None)
        if not os.environ.get("MSZ_NO_TRAY"):
            self.tray.show()

    # ================= 绑定 =================
    def _wire(self):
        b = self.bus
        b.log.connect(self._append_log)
        b.phase.connect(self._on_phase)
        b.result.connect(self._on_result)
        b.schedule.connect(self._on_schedule)
        b.login_bad.connect(self._on_login_bad)
        b.job_done.connect(self._on_job_done)
        b.login_done.connect(self._on_login_done)
        b.rooms_read.connect(self._on_rooms_read)
        self.btn_read_rooms.clicked.connect(self._read_rooms)

        self.btn_daemon.clicked.connect(self.start_daemon)
        self.btn_stop.clicked.connect(self.stop_job)
        self.btn_test.clicked.connect(lambda: self.start_job("test"))
        self.btn_once.clicked.connect(lambda: self.start_job("once"))
        self.btn_login.clicked.connect(self.do_login)

        ch = self._changed
        self.ed_topic.textChanged.connect(ch)
        self.cb_start.currentIndexChanged.connect(ch)
        self.sp_hours.valueChanged.connect(ch)
        self.cb_min.currentIndexChanged.connect(ch)
        for btn in self.day_btns:
            btn.toggled.connect(ch)
        self.rooms.model().rowsMoved.connect(ch)
        self.rooms.itemChanged.connect(ch)
        self.ck_fallback.toggled.connect(ch)
        self.btn_add.clicked.connect(self._add_room)
        self.ed_room.returnPressed.connect(self._add_room)
        self.btn_del.clicked.connect(self._del_room)
        self.btn_up.clicked.connect(lambda: self._move_room(-1))
        self.btn_down.clicked.connect(lambda: self._move_room(1))
        self.post_group.buttonClicked.connect(ch)
        self.ed_receiver.textChanged.connect(ch)
        self.sp_remind.valueChanged.connect(ch)
        self.btn_cli_test.clicked.connect(self._cli_test)
        self.btn_pending_del.clicked.connect(self._del_pending)
        for w in (self.sp_lead, self.sp_retry, self.sp_interval, self.sp_pre, self.sp_gx, self.sp_gw):
            w.valueChanged.connect(ch)
        self.te_open.timeChanged.connect(ch)
        self.te_gs.timeChanged.connect(ch)
        for w in (self.ck_clock, self.ck_awake, self.ck_calib):
            w.toggled.connect(ch)
        self.ck_autostart.toggled.connect(self._toggle_autostart)
        self.ck_autoupd.toggled.connect(ch)
        self.ed_url.textChanged.connect(ch)
        self.ed_cli.textChanged.connect(ch)
        self.cb_browser.currentIndexChanged.connect(ch)

    def _load_into_ui(self):
        c = self.cfg
        self.ed_topic.setText(c["主题"])
        if self.cb_start.findText(c["开始时间"]) < 0:
            self.cb_start.addItem(c["开始时间"])
        self.cb_start.setCurrentText(c["开始时间"])
        self.sp_hours.setValue(int(c["时长小时"]))
        self.cb_min.setCurrentText(f'{int(c["时长分钟"]):02d}')
        for i, btn in enumerate(self.day_btns):
            btn.setChecked((i + 1) in c.get("抢订日", []))
        self.rooms.clear()
        for r in c["优先会议室"]:
            self._room_item(r)
        s = c["抢订设置"]
        self.ck_fallback.setChecked(bool(s.get("抢不到换下一间", True)))
        self.post_group.button(C.POST_MODES.index(c["会后动作"]["模式"])).setChecked(True)
        self.ed_receiver.setText(c["会后动作"].get("小鲁班ID", ""))
        self.sp_remind.setValue(int(c["会后动作"].get("提醒提前分钟", 5)))
        self.te_open.setTime(QTime.fromString(s["开放时间"], "HH:mm:ss"))
        self.sp_lead.setValue(int(s["提前填表秒数"]))
        self.sp_retry.setValue(int(s["最大重试次数"]))
        self.sp_interval.setValue(int(s["重试间隔毫秒"]))
        self.sp_pre.setValue(int(s.get("登录预检提前分钟", 15)))
        self.ck_clock.setChecked(bool(s.get("校准服务器时间", True)))
        sy = c["系统"]
        self.ck_awake.setChecked(bool(sy.get("守护时阻止睡眠", True)))
        self.ck_autoupd.setChecked(bool(sy.get("自动检查更新", True)))
        try:
            self.ck_autostart.setChecked(system.autostart_enabled())
        except Exception:
            pass
        a = c["高级"]
        self.ed_url.setText(a["网址"])
        self.ck_calib.setChecked(bool(a.get("自动标定网格", True)))
        self.sp_gx.setValue(int(a["网格起点X"]))
        self.sp_gw.setValue(int(a["格子宽度"]))
        self.te_gs.setTime(QTime.fromString(a["网格起始时间"], "HH:mm"))
        self.cb_browser.setCurrentText(a.get("浏览器", "自动"))
        self.ed_cli.setText(a.get("welink-cli路径", ""))

    def _room_item(self, name):
        it = QListWidgetItem(name)
        it.setFlags(it.flags() | Qt.ItemIsEditable)
        self.rooms.addItem(it)

    def _changed(self, *_):
        if self._loading:
            return
        c = self.cfg
        c["主题"] = self.ed_topic.text().strip() or "日常会议"
        c["开始时间"] = self.cb_start.currentText()
        c["时长小时"] = self.sp_hours.value()
        c["时长分钟"] = int(self.cb_min.currentText())
        c["抢订日"] = [i + 1 for i, b in enumerate(self.day_btns) if b.isChecked()]
        c["优先会议室"] = [self.rooms.item(i).text().strip() for i in range(self.rooms.count()) if self.rooms.item(i).text().strip()]
        s = c["抢订设置"]
        s["抢不到换下一间"] = self.ck_fallback.isChecked()
        s["开放时间"] = self.te_open.time().toString("HH:mm:ss")
        s["提前填表秒数"] = self.sp_lead.value()
        s["最大重试次数"] = self.sp_retry.value()
        s["重试间隔毫秒"] = self.sp_interval.value()
        s["登录预检提前分钟"] = self.sp_pre.value()
        s["校准服务器时间"] = self.ck_clock.isChecked()
        c["会后动作"]["模式"] = C.POST_MODES[max(0, self.post_group.checkedId())]
        c["会后动作"]["小鲁班ID"] = self.ed_receiver.text().strip() or "p_xiaoluban"
        c["会后动作"]["提醒提前分钟"] = self.sp_remind.value()
        c["系统"]["守护时阻止睡眠"] = self.ck_awake.isChecked()
        c["系统"]["自动检查更新"] = self.ck_autoupd.isChecked()
        a = c["高级"]
        a["网址"] = self.ed_url.text().strip() or C.DEFAULT_URL
        a["自动标定网格"] = self.ck_calib.isChecked()
        a["网格起点X"] = self.sp_gx.value()
        a["格子宽度"] = self.sp_gw.value()
        a["网格起始时间"] = self.te_gs.time().toString("HH:mm")
        a["浏览器"] = self.cb_browser.currentText()
        a["welink-cli路径"] = self.ed_cli.text().strip()
        self.save_timer.start()
        self.refresh_all()

    def _save_now(self):
        C.save_config(self.cfg)
        self.saved_lbl.setText(f"已保存 {datetime.now():%H:%M:%S}")

    def _add_room(self):
        n = self.ed_room.text().strip()
        if not n:
            return
        if n in self.cfg["优先会议室"]:
            self.log(f"{n} 已在列表里", "warn")
            return
        self._room_item(n)
        self.ed_room.clear()
        self._changed()

    def _del_room(self):
        r = self.rooms.currentRow()
        if r >= 0:
            self.rooms.takeItem(r)
            self._changed()

    def _move_room(self, d):
        r = self.rooms.currentRow()
        t = r + d
        if r < 0 or t < 0 or t >= self.rooms.count():
            return
        it = self.rooms.takeItem(r)
        self.rooms.insertItem(t, it)
        self.rooms.setCurrentRow(t)
        self._changed()

    def _read_rooms(self):
        if self._busy():
            self.log("有任务在运行，先点「停止」再读取会议室", "warn")
            return
        self.btn_read_rooms.setEnabled(False)
        self.btn_read_rooms.setText("读取中…")
        self.log("正在打开会议室页面读取会议室列表…")
        cfg, b = self.cfg, self.bus
        day = (datetime.now() + timedelta(weeks=1)).strftime("%Y/%m/%d")

        def work():
            names = None
            try:
                names = read_rooms(cfg, lambda m, l="info": b.log.emit(m, l), threading.Event(), day)
            except Exception as e:
                b.log.emit(f"读取会议室失败：{e}", "bad")
            b.rooms_read.emit(names)

        threading.Thread(target=work, daemon=True).start()

    def _on_rooms_read(self, names):
        self.btn_read_rooms.setEnabled(True)
        self.btn_read_rooms.setText("从页面读取")
        if not names:
            return
        have = set(self.cfg["优先会议室"])
        dlg = QDialog(self)
        dlg.setWindowTitle("选择优先会议室")
        v = QVBoxLayout(dlg)
        v.setContentsMargins(20, 18, 20, 16)
        v.addWidget(label(f"页面上能看到 {len(names)} 间。勾选要抢的，加入后可在列表里拖动排序。", "Help", wrap=True))
        lst = QListWidget()
        lst.setObjectName("Rooms")
        lst.setMinimumSize(420, 300)
        for n in names:
            it = QListWidgetItem(n + ("（已在列表里）" if n in have else ""))
            it.setData(Qt.UserRole, n)
            if n in have:
                it.setFlags(it.flags() & ~Qt.ItemIsEnabled)
            else:
                it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
                it.setCheckState(Qt.Unchecked)
            lst.addItem(it)
        v.addWidget(lst)
        bb = QDialogButtonBox()
        ok = bb.addButton("加入所选", QDialogButtonBox.AcceptRole)
        ok.setObjectName("Primary")
        bb.addButton("取消", QDialogButtonBox.RejectRole)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        self.room_picker = dlg
        if dlg.exec_() != QDialog.Accepted:
            return
        added = [lst.item(i).data(Qt.UserRole) for i in range(lst.count())
                 if lst.item(i).flags() & Qt.ItemIsUserCheckable and lst.item(i).checkState() == Qt.Checked]
        for n in added:
            self._room_item(n)
        if added:
            self._changed()
            self.log(f"已加入 {len(added)} 间会议室：{'、'.join(added)}", "ok")

    def _toggle_autostart(self, on):
        if self._loading:
            return
        try:
            system.set_autostart(on)
            self.cfg["系统"]["开机自动启动守护"] = on
            self.save_timer.start()
            self.log("已设置开机自动启动守护" if on else "已取消开机自动启动", "ok")
        except Exception as e:
            self.log(f"设置开机启动失败：{e}", "bad")

    # ================= 任务 =================
    def _runner(self):
        b = self.bus
        return Runner(self.cfg, lambda m, l="info": b.log.emit(m, l), lambda k, s, t: b.phase.emit(k, s, t), self.stop_event, self.clock)

    def _busy(self):
        return self.job_thread is not None and self.job_thread.is_alive()

    def start_job(self, mode):
        if self._busy():
            self.log("已有任务在运行，先点「停止」", "warn")
            return
        if not self.cfg["优先会议室"]:
            self.log("优先会议室列表是空的，先去「抢订计划」添加", "bad")
            self.nav.setCurrentRow(1)
            return
        self._save_now()
        self.stop_event = threading.Event()
        self.job = mode
        self.phases = {}
        r = self._runner()
        b = self.bus

        def work():
            try:
                if mode == "daemon":
                    r.run_daemon(
                        on_result=lambda res: b.result.emit(res),
                        on_login_bad=lambda: b.login_bad.emit(),
                        on_schedule=lambda o, t, ok: b.schedule.emit(o, t, ok),
                    )
                else:
                    res = r.run_once(test=(mode == "test"))
                    b.result.emit(res)
            except Exception as e:
                b.log.emit(f"任务异常退出：{e}", "bad")
            finally:
                if r.login_ok is not None:
                    b.login_done.emit(bool(r.login_ok))
                b.job_done.emit(mode)

        self.job_thread = threading.Thread(target=work, daemon=True)
        self.job_thread.start()
        names = {"daemon": "守护已启动", "once": "开始：立即抢一次", "test": "开始：测试填表（不会提交）"}
        self.log(names[mode], "ok")
        if mode == "daemon" and self.cfg["系统"].get("守护时阻止睡眠", True):
            system.keep_awake(True)
        self.refresh_all()

    def start_daemon(self):
        self.start_job("daemon")

    def stop_job(self):
        if self.stop_event:
            self.stop_event.set()
            self.log("正在停止…（浏览器操作到下一步时退出）")

    def _on_job_done(self, mode):
        self.job = None
        self.next_open = None
        system.keep_awake(False)
        self.refresh_all()

    def do_login(self):
        self.log("打开浏览器供你登录…")
        self.btn_login.setEnabled(False)
        ev = threading.Event()
        cfg = self.cfg
        b = self.bus

        def work():
            ok = False
            try:
                ok = interactive_login(cfg, lambda m, l="info": b.log.emit(m, l), ev)
            except Exception as e:
                b.log.emit(f"打开登录浏览器失败：{e}", "bad")
            b.login_done.emit(ok)

        threading.Thread(target=work, daemon=True).start()

    def _on_login_done(self, ok):
        self.btn_login.setEnabled(True)
        self.login_state = ok
        self.login_checked_at = datetime.now()
        self.refresh_all()

    def _on_login_bad(self):
        self.login_state = False
        self.login_checked_at = datetime.now()
        self.show_window()
        self.tray.showMessage(C.APP_NAME, "WeLink 登录已失效，请在开放前重新登录", QSystemTrayIcon.Warning, 15000)
        rec = self.cfg["会后动作"].get("小鲁班ID")
        if rec and welink.find_cli(self.cfg["高级"].get("welink-cli路径", "")):
            threading.Thread(target=lambda: self._safe_send(rec, f"秘书终结者提醒：WeLink 会议室页面登录已失效，{self.cfg['抢订设置']['开放时间'][:5]} 前请在电脑上重新登录。"), daemon=True).start()
        self.refresh_all()

    def _safe_send(self, rec, text):
        try:
            welink.send(rec, text, self.cfg["高级"].get("welink-cli路径", ""))
            self.bus.log.emit("已通过 WeLink 发送登录失效提醒", "ok")
        except Exception as e:
            self.bus.log.emit(f"WeLink 提醒没发出去：{e}", "warn")

    def _on_result(self, res):
        st = res.get("status")
        if st == "成功":
            n = post.schedule_for(self.cfg, res)
            if n:
                self.log(f"已排入会后动作：{self.cfg['会后动作']['模式']}", "ok")
                self._on_phase("post", "wait", self._post_desc())
            self.tray.showMessage(C.APP_NAME, f"抢到了：{res['room']}（{res['date']}）", QSystemTrayIcon.Information, 10000)
        elif st == "测试":
            self.tray.showMessage(C.APP_NAME, f"测试填表完成：会选 {res['room']}", QSystemTrayIcon.Information, 6000)
        elif st != "取消":
            self.tray.showMessage(C.APP_NAME, f"{st}：{res.get('note') or ''}", QSystemTrayIcon.Warning, 10000)
        if res.get("note", "").startswith("登录失效"):
            self.login_state = False
            self.login_checked_at = datetime.now()
        self.refresh_all()

    def _on_schedule(self, open_at, target, active):
        self.next_open = open_at
        self.next_target = target
        self.refresh_all()

    def _on_phase(self, key, status, text):
        self.phases[key] = (status, text)
        if key == "precheck" and status in ("ok", "bad"):
            self.login_state = status == "ok"
            self.login_checked_at = datetime.now()
        self._render_flow()
        if key == "precheck" and status in ("ok", "bad"):
            self.refresh_all()

    def _post_desc(self):
        m = self.cfg["会后动作"]["模式"]
        if m == "通知模式":
            return f"抢到后，会前 {self.cfg['会后动作']['提醒提前分钟']} 分钟发提醒"
        if m == "自动释放":
            return "抢到后，会议开始时自动取消释放"
        return "不动作"

    def _run_post_actions(self):
        items = post.pending()
        self._render_pending(items)
        if not any(datetime.fromisoformat(a["due"]) <= datetime.now() for a in items):
            return
        cfg = self.cfg
        b = self.bus
        threading.Thread(target=lambda: post.run_due(cfg, lambda m, l="info": b.log.emit(m, l)), daemon=True).start()
        QTimer.singleShot(5000, lambda: self._render_pending(post.pending()))

    def _cli_test(self):
        rec = self.cfg["会后动作"].get("小鲁班ID")
        threading.Thread(target=lambda: self._safe_send(rec, f"秘书终结者测试消息 {datetime.now():%H:%M:%S}"), daemon=True).start()

    def _del_pending(self):
        it = self.pending_list.currentItem()
        if it and it.data(Qt.UserRole):
            post.remove(it.data(Qt.UserRole))
            self._render_pending(post.pending())

    # ================= 刷新显示 =================
    def _on_nav(self, i):
        self.stack.setCurrentIndex(i)
        if i == 3:
            self._render_history()
        if i == 2:
            self._render_pending(post.pending())

    def _calc_next(self):
        if self.next_open:
            return self.next_open, self.next_target
        r = Runner(self.cfg, lambda *a: None, lambda *a: None, threading.Event(), self.clock)
        o = r.next_open()
        return o, o.date() + timedelta(weeks=1)

    def _on_tick(self):
        o, _ = self._calc_next()
        remain = (o - self.clock.now()).total_seconds()
        v, n = self.stat["count"]
        if remain < 0:
            v.setText("进行中")
        else:
            hh, rem = divmod(int(remain), 3600)
            mm, ss = divmod(rem, 60)
            v.setText(f"{hh:02d}:{mm:02d}:{ss:02d}")
        v.setStyleSheet(f"color:{ACC};" if self.job == "daemon" else f"color:{INK};")
        n.setText(f"{'今天' if o.date() == datetime.now().date() else '明天'} {o:%H:%M:%S} 开放")

    def refresh_all(self):
        cfg = self.cfg
        o, target = self._calc_next()
        h, m = map(int, cfg["开始时间"].split(":"))
        end = datetime(2000, 1, 1, h, m) + timedelta(hours=int(cfg["时长小时"]), minutes=int(cfg["时长分钟"]))
        span = f"{cfg['开始时间']}–{end:%H:%M}"
        day_word = "今天" if o.date() == datetime.now().date() else "明天"
        wk_ok = target.isoweekday() in cfg.get("抢订日", [])
        rooms = cfg["优先会议室"]
        if self.job == "daemon":
            if wk_ok:
                self.ov.h1.setText(f"守护中：{day_word} {o:%H:%M} 抢 {target:%m/%d}（{WD[target.weekday()]}）{span}")
            else:
                self.ov.h1.setText(f"守护中：{target:%m/%d}（{WD[target.weekday()]}）不在抢订日里，{day_word}跳过")
        elif self.job == "once":
            self.ov.h1.setText(f"正在立即抢一次：{target:%m/%d}（{WD[target.weekday()]}）{span}")
        elif self.job == "test":
            self.ov.h1.setText("正在测试填表（不会提交）")
        else:
            self.ov.h1.setText(f"守护未启动 · 下一次可抢 {target:%m/%d}（{WD[target.weekday()]}）{span}")
        if rooms:
            self.ov.sub.setText(f"按顺序试 {len(rooms)} 间会议室，首选 {rooms[0]}；会后动作：{cfg['会后动作']['模式']}。")
        else:
            self.ov.sub.setText("还没设置优先会议室：先点「登录 / 检查登录」，再到「抢订计划」点「从页面读取」勾选会议室。")

        v, n = self.stat["target"]
        v.setText(f"{target:%m/%d}")
        n.setText(f"{WD[target.weekday()]} {span}" + ("" if wk_ok else "（不在抢订日，跳过）"))
        v, n = self.stat["login"]
        if self.login_state is None:
            v.setText("未检查")
            v.setStyleSheet(f"color:{FAINT};")
            n.setText(f"开放前 {cfg['抢订设置'].get('登录预检提前分钟', 15)} 分钟自动检查")
        elif self.login_state:
            v.setText("有效")
            v.setStyleSheet(f"color:{OK};")
            n.setText(f"{self.login_checked_at:%H:%M} 检查")
        else:
            v.setText("失效")
            v.setStyleSheet(f"color:{BAD};")
            n.setText(f"{self.login_checked_at:%H:%M} 发现，需要重新登录")
        self.alert.setVisible(self.login_state is False)
        self.alert_text.setText(f"WeLink 登录已失效。请在 {cfg['抢订设置']['开放时间'][:5]} 前点右边按钮，在弹出的浏览器里登录一次（登录成功会自动关闭）。")
        hist = C.load_history()
        v, n = self.stat["last"]
        real = [x for x in hist if x.get("状态") != "测试"]
        if real:
            last = real[-1]
            fg, _ = tone_color(last["状态"])
            v.setText(last["状态"])
            v.setStyleSheet(f"color:{fg};")
            n.setText(f"{last['日期'][5:]} {last.get('会议室') or last.get('备注', '')[:18]}")
        else:
            v.setText("—")
            n.setText("还没有记录")
        self._render_recent(hist)
        self._render_flow()
        if hasattr(self, "tick"):
            self._on_tick()

        busy = self._busy()
        self.btn_daemon.setEnabled(not busy)
        self.btn_test.setEnabled(not busy)
        self.btn_once.setEnabled(not busy)
        self.btn_stop.setEnabled(busy)
        self.act_daemon.setEnabled(not busy) if hasattr(self, "act_daemon") else None
        self.act_stop.setEnabled(busy) if hasattr(self, "act_stop") else None
        dot, txt = (OK, "守护中") if self.job == "daemon" else ((ACC, "运行中") if busy else (FAINT, "未启动"))
        self.side_status.setText(f"<span style='color:{dot}; font-size:16px'>●</span> <span style='color:{INK2}'>{txt}</span>"
                                 f"<br><span style='color:{FAINT}; font-size:12px'>v{C.VERSION}"
                                 f"{'（更新包）' if os.environ.get('MSZ_CODE_VERSION') else ''}</span>")
        self.tray.setToolTip(f"{C.APP_NAME} · {txt}") if hasattr(self, "tray") else None

        # 其他页的提示
        total = int(cfg["时长小时"]) * 60 + int(cfg["时长分钟"])
        self.dur_hint.setText(f"共 {total} 分钟，占 {max(1, -(-total // 30))} 个半小时格子；结束于 {end:%H:%M}")
        on = [WD[i - 1] for i in cfg.get("抢订日", [])]
        self.days_hint.setText(("按目标日（下周同一天）算。当前抢：" + "、".join(on)) if on else "一天都没勾，守护不会抢任何一天。")
        lead = cfg["抢订设置"]["提前填表秒数"]
        last_prep = next((h for h in reversed(hist) if "准备晚了" in (h.get("备注") or "")), None)
        self.lead_hint.setText("填表选房一般要 20–30 秒；建议 60 秒留余量" + (f"。注意：{last_prep['日期']} 曾{last_prep['备注']}" if last_prep else ""))
        self.clock_lbl.setText(self.clock.describe())
        cli = welink.find_cli(cfg["高级"].get("welink-cli路径", ""))
        self.cli_lbl.setText(f"<span style='color:{OK}'>已找到</span>：{cli}" if cli else f"<span style='color:{WARN}'>没找到 welink-cli</span>：会后动作和登录失效消息提醒不可用，抢订不受影响。")
        self.btn_cli_test.setEnabled(bool(cli))

    def _render_flow(self):
        colors = {"wait": (FAINT, False), "run": (ACC, True), "ok": (OK, True), "bad": (BAD, True), "skip": ("#c8c8ce", True)}
        defaults = {
            "precheck": "开放前自动检查登录" if self.cfg["抢订设置"].get("登录预检提前分钟", 15) else "未开启",
            "prepare": f"开放前 {self.cfg['抢订设置']['提前填表秒数']} 秒开始",
            "submit": f"{self.cfg['抢订设置']['开放时间']} 连点「预定」",
            "post": self._post_desc(),
        }
        for k, (dot, d) in self.flow_rows.items():
            st, text = self.phases.get(k, ("wait", defaults[k]))
            c, filled = colors.get(st, (FAINT, False))
            dot.setStyleSheet(f"border-radius:5px; border:2px solid {c}; background:{c if filled else 'transparent'};")
            d.setText(text)

    def _render_recent(self, hist):
        while self.recent_box.count():
            it = self.recent_box.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()
            elif it.layout():
                lay = it.layout()
                while lay.count():
                    x = lay.takeAt(0).widget()
                    if x:
                        x.deleteLater()
        rows = list(reversed(hist[-5:]))
        if not rows:
            self.recent_box.addWidget(label("还没有抢订记录", "Help"))
            return
        for hrec in rows:
            row = QHBoxLayout()
            d = datetime.strptime(hrec["日期"], "%Y-%m-%d")
            row.addWidget(label(f"{d:%m/%d} {WD[d.weekday()]}"))
            fg, bg = tone_color(hrec["状态"])
            row.addWidget(pill(hrec["状态"], fg, bg))
            row.addStretch(1)
            r = label(hrec.get("会议室") or "—")
            r.setStyleSheet(f"color:{MUTE}; font-size:13px;")
            row.addWidget(r)
            self.recent_box.addLayout(row)

    def _render_history(self):
        hist = list(reversed(C.load_history()))
        self.table.setRowCount(len(hist))
        for i, hrec in enumerate(hist):
            vals = [hrec.get("日期", ""), hrec.get("时间", ""), "", hrec.get("会议室") or "—", hrec.get("时间戳", ""), hrec.get("备注", "")]
            for j, v in enumerate(vals):
                if j == 2:
                    fg, bg = tone_color(hrec.get("状态", ""))
                    w = QWidget()
                    l = QHBoxLayout(w)
                    l.setContentsMargins(6, 0, 0, 0)
                    l.addWidget(pill(hrec.get("状态", ""), fg, bg))
                    l.addStretch(1)
                    self.table.setCellWidget(i, j, w)
                else:
                    it = QTableWidgetItem(str(v))
                    if j == 5:
                        it.setToolTip(str(v))
                    self.table.setItem(i, j, it)

    def _render_pending(self, items):
        self.pending_list.clear()
        if not items:
            it = QListWidgetItem("暂无")
            it.setForeground(QColor(FAINT))
            self.pending_list.addItem(it)
            return
        for a in items:
            it = QListWidgetItem(post.describe(a))
            it.setData(Qt.UserRole, a["id"])
            self.pending_list.addItem(it)

    # ================= 日志 =================
    def log(self, msg, level="info"):
        self._append_log(msg, level)

    def _append_log(self, msg, level):
        ts = datetime.now().strftime("%H:%M:%S")
        color = {"ok": OK, "warn": WARN, "bad": BAD}.get(level, INK2)
        esc = msg.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        self.log_view.append(f"<span style='color:{FAINT}'>{ts}</span>&nbsp;&nbsp;<span style='color:{color}'>{esc}</span>")
        self.log_view.moveCursor(QTextCursor.End)
        try:
            with open(C.path("logs", f"{datetime.now():%Y%m%d}.log"), "a", encoding="utf-8") as f:
                f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} [{level}] {msg}\n")
        except OSError:
            pass

    def _open_dir(self, sub):
        p = C.path(sub) if sub else C.app_dir()
        os.makedirs(p, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(p))

    # ================= 窗口与托盘 =================
    def show_window(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def closeEvent(self, e):
        if self.job == "daemon" or post.pending():
            e.ignore()
            self.hide()
            why = "守护继续运行" if self.job == "daemon" else "还有待执行的会后动作"
            self.tray.showMessage(C.APP_NAME, f"已收到托盘，{why}。右键托盘图标可退出。", QSystemTrayIcon.Information, 5000)
        else:
            self.quit_app()

    def _render_update_entry(self):
        u = self.updater
        if u is None:
            return
        self.upd_btn.setText(u.entry_text())
        hot = bool(u.pending_version())
        self.upd_btn.setProperty("hot", "true" if hot else "false")
        self.upd_btn.style().unpolish(self.upd_btn)
        self.upd_btn.style().polish(self.upd_btn)
        self.upd_dot.setVisible(u.is_unread())
        self.ver_lbl.setText(f"当前版本 <b>v{C.VERSION}</b>　程序代码：{update.code_origin()}；"
                             f"exe v{update.exe_version()}（运行环境 {update.exe_shell()}）")

    def _make_share(self):
        try:
            p = share.make_package()
        except Exception as e:
            self.log(f"生成分享包失败：{e}", "bad")
            return
        self.log(f"分享包已生成：{p}（只含程序和使用说明）", "ok")
        QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(p)))

    def quit_app(self):
        if self.updater is not None:
            self.updater.shutdown()
        if self.stop_event:
            self.stop_event.set()
        system.keep_awake(False)
        self.tray.hide()
        QApplication.instance().quit()


def apply_theme(app):
    app.setStyle("Fusion")
    pal = app.palette()
    pal.setColor(QPalette.Window, QColor("#f8f8fa"))
    pal.setColor(QPalette.Base, QColor("#ffffff"))
    pal.setColor(QPalette.Highlight, QColor(ACC))
    pal.setColor(QPalette.HighlightedText, QColor("#ffffff"))
    pal.setColor(QPalette.Text, QColor(INK2))
    pal.setColor(QPalette.WindowText, QColor(INK2))
    pal.setColor(QPalette.Button, QColor("#ffffff"))
    pal.setColor(QPalette.ButtonText, QColor(INK2))
    app.setPalette(pal)
    f = QFont("Microsoft YaHei UI")
    f.setPixelSize(14)
    app.setFont(f)
    app.setStyleSheet(QSS)
