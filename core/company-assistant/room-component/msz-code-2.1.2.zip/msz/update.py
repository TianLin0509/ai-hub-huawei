"""在线更新：GitHub 为主、阿里云备用；平时只换程序代码，运行环境变了才换整个 exe。

做法借鉴 PPT Doctor v2.0.3 与 AI Hub 公司版（两者都在公司网络实测过）：
- 各源同时查清单，取版本最高的那份（某个源忘了同步也不会让大家永远收不到更新）；
- 下载逐源回落：每个源下完都核对大小和 sha256，被公司代理换成拦截网页时说人话、换下一个源；
- 「立即重启」要确认新进程真的起来了（新进程写回执）才退出；没起来就留在原地、可重试。

两层更新：
- 代码更新（kind="code"）：清单里的 code 是 msz 程序代码的 zip（几十 KB）。exe 不动，
  下次启动时启动器（app.py）从 updates/ 加载新代码。exe 的运行环境（version.SHELL）必须一致。
- 整包更新（kind="exe"）：运行环境变了（换 Python/PyQt5/Playwright 版本），下载新 exe（约 75 MB），
  把正在运行的 exe 改名为 .old（Windows 允许给运行中的 exe 改名），新 exe 放到原位置再启动。

安全：清单必须带发布者私钥的 Ed25519 签名（见 ed25519.py），程序只认内置公钥。
清单里写着每个文件的 sha256，所以文件本身也被签名间接保护。

本模块不依赖 Qt，便于测试；界面在 update_ui.py。
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from dataclasses import dataclass, field

from . import config as C
from . import ed25519, netfetch
from .version import SHELL, VERSION

APP_ID = "mishu-terminator"
MANIFEST = "latest.json"
PUBLIC_KEY = bytes.fromhex("484b4c7e2085c284d6a569b95c8defd152dec09a2f3015a9be18c5df8ec2bed4")
GITHUB_REPO = "TianLin0509/mishu-terminator"
RELEASE_PAGE = f"https://github.com/{GITHUB_REPO}/releases/latest"
# 按下载时的尝试顺序。公司实测（AI Hub 2026-10-13）：GitHub 经公司代理直通约 2 MB/s；
# 阿里云小文件正常、大文件会被代理换成拦截页，所以阿里云排第二，主要兜底清单和代码小包。
DEFAULT_SOURCES = [
    ("github", f"https://github.com/{GITHUB_REPO}/releases/latest/download"),
    # 放在 AI Hub 已有的静态路由 /hub-update/ 下面，不用改服务器的 Caddy 配置
    ("aliyun", "https://me.lt-stockpartner.tech/hub-update/mishu"),
]
KEEP_CODE = 2  # updates/ 里保留最近几个代码包


# ---------- 版本与源 ----------
def vtuple(v):
    out = []
    for part in str(v or "0").split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits or 0))
    return tuple(out + [0] * (4 - len(out)))


def exe_shell():
    """当前 exe 的运行环境版本。启动器把它放进环境变量；源码运行时就是本文件的 SHELL。"""
    return int(os.environ.get("MSZ_EXE_SHELL") or SHELL)


def exe_version():
    return os.environ.get("MSZ_EXE_VERSION") or VERSION


def code_origin():
    """「内置」或「更新包 vX」。"""
    v = os.environ.get("MSZ_CODE_VERSION")
    return f"更新包 v{v}" if v else "内置"


def sources():
    """[(label, base_url)]。环境变量 MSZ_UPDATE_SOURCES="label|url;label|url" 覆盖（测试用）。"""
    env = os.environ.get("MSZ_UPDATE_SOURCES", "").strip()
    if env:
        out = []
        for i, item in enumerate(x for x in env.split(";") if x.strip()):
            label, _, url = item.partition("|")
            if not url:
                label, url = f"source{i + 1}", label
            out.append((label.strip(), url.strip().rstrip("/")))
        return out
    return list(DEFAULT_SOURCES)


def updates_dir(*parts):
    return C.path("updates", *parts)


# ---------- 清单与签名 ----------
def canonical(manifest):
    body = {k: v for k, v in manifest.items() if k != "signature"}
    return json.dumps(body, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def sign_manifest(manifest, secret):
    manifest["signature"] = ed25519.sign(secret, canonical(manifest)).hex()
    return manifest


def verify_manifest(manifest, public=PUBLIC_KEY):
    sig = manifest.get("signature") or ""
    try:
        ok = ed25519.verify(public, canonical(manifest), bytes.fromhex(sig))
    except ValueError:
        ok = False
    if not ok:
        raise netfetch.SourceFailure("清单签名不对（不是发布者发的，或在路上被改过），已拒绝")


def fetch_manifest(base, timeout=8.0, response_callback=None):
    req = urllib.request.Request(f"{base}/{MANIFEST}", headers={"Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        if response_callback:
            response_callback(r)
        try:
            raw = r.read(1024 * 1024)
        finally:
            if response_callback:
                response_callback(None)
        ctype = r.headers.get("Content-Type") or ""
    if netfetch.looks_like_web_page(ctype, raw):
        raise netfetch.SourceFailure(f"收到的是网页（{netfetch.fmt_bytes(len(raw))}）而不是版本清单，可能被公司代理拦截")
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as e:
        raise netfetch.SourceFailure(f"版本清单无效：{e}"[:120]) from e
    if not isinstance(data, dict) or data.get("app") != APP_ID:
        raise netfetch.SourceFailure("版本清单无效：不是秘书终结者的清单")
    verify_manifest(data)
    return data


@dataclass
class UpdateInfo:
    version: str
    kind: str            # code / exe
    file: str
    size: int
    sha256: str
    notes: list = field(default_factory=list)
    date: str = ""
    shell: int = SHELL
    sources: list = field(default_factory=list)   # [(label, base)]，按尝试顺序
    used_source: str = ""

    @property
    def source_names(self):
        return [netfetch.source_name(label) for label, _ in self.sources]


def plan(remote, current=None, shell=None):
    """远端清单 → 要不要更新、换代码还是换 exe。不需要更新返回 None。"""
    current = current or VERSION
    shell = exe_shell() if shell is None else shell
    if vtuple(remote.get("version")) <= vtuple(current):
        return None
    common = dict(version=str(remote["version"]), notes=list(remote.get("notes") or []),
                  date=str(remote.get("date", "")), shell=int(remote.get("shell", 0)))
    code, exe = remote.get("code"), remote.get("exe")
    if code and int(remote.get("shell", -1)) == shell:
        return UpdateInfo(kind="code", file=code["file"], size=int(code["size"]), sha256=code["sha256"], **common)
    if exe:
        return UpdateInfo(kind="exe", file=exe["file"], size=int(exe["size"]), sha256=exe["sha256"], **common)
    return None


@dataclass
class SourceCheck:
    label: str
    name: str
    ok: bool
    version: str = ""
    reason: str = ""
    ms: int = 0

    def as_dict(self):
        return {"label": self.label, "name": self.name, "ok": self.ok, "version": self.version,
                "reason": self.reason, "ms": self.ms}


@dataclass
class CheckReport:
    best: object
    checks: list
    current: str = VERSION
    error: str = ""

    @property
    def all_failed(self):
        return bool(self.checks) and not any(c.ok for c in self.checks)


def check(timeout=8.0, response_callback=None):
    """各源同时查清单，取版本最高的那份；同版本的其它源按顺序排在后面供下载回落。"""
    srcs = sources()

    def one(item):
        label, base = item
        t0 = time.monotonic()
        try:
            m = fetch_manifest(base, timeout, response_callback)
            return item, m, SourceCheck(label, netfetch.source_name(label), True, str(m.get("version", "")),
                                        ms=int((time.monotonic() - t0) * 1000))
        except Exception as e:  # noqa: BLE001 一个源的任何问题都不该拖垮整次检查
            return item, None, SourceCheck(label, netfetch.source_name(label), False, reason=netfetch.reason_of(e),
                                           ms=int((time.monotonic() - t0) * 1000))

    with ThreadPoolExecutor(max_workers=max(1, len(srcs))) as pool:
        results = list(pool.map(one, srcs))
    checks = [c for _, _, c in results]
    best_v, best = None, None
    for item, m, _ in results:
        if m is not None and (best_v is None or vtuple(m["version"]) > vtuple(best_v)):
            best_v, best = m["version"], m
    info = plan(best) if best else None
    if info:
        info.sources = [item for item, m, _ in results if m is not None and m.get("version") == best_v]
    rep = CheckReport(best=info, checks=checks)
    if rep.all_failed:
        rep.error = "所有更新源都连不上：" + "；".join(f"{c.name}：{c.reason}" for c in checks)
    return rep


# ---------- 下载 ----------
def download(info, cancel=None, on_status=None, on_attempts=None, response_callback=None):
    """逐源下载到 updates/，核对大小、sha256；代码包再核对里面的版本号。返回本地路径。"""
    os.makedirs(updates_dir(), exist_ok=True)
    dest = updates_dir(info.file)
    what = "程序代码" if info.kind == "code" else "新版程序"
    cands = [(label, f"{base}/{info.file}") for label, base in info.sources]
    ok, _ = netfetch.download_with_fallback(
        cands, dest, expect_size=info.size, expect_sha256=info.sha256, timeout=20,
        cancel=cancel, on_status=on_status, on_attempts=on_attempts,
        response_callback=response_callback, what=what)
    info.used_source = ok.name
    if info.kind == "code":
        check_code_zip(dest, info.version, info.shell)
    return dest


def read_code_zip(path):
    """代码包里的 (VERSION, SHELL)；不是合格代码包抛 ValueError。"""
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        if "msz/__init__.py" not in names or "msz/version.py" not in names or "msz/entry.py" not in names:
            raise ValueError("代码包不完整（缺少 msz/__init__.py、version.py 或 entry.py）")
        ns = {}
        exec(compile(z.read("msz/version.py").decode("utf-8"), "version.py", "exec"), ns)  # noqa: S102 只含两个常量，且整包已验签
    return str(ns.get("VERSION")), int(ns.get("SHELL", -1))


def check_code_zip(path, version, shell):
    v, s = read_code_zip(path)
    if v != version or s != shell:
        raise ValueError(f"代码包内容不对：里面是 v{v}（运行环境 {s}），清单写的是 v{version}（运行环境 {shell}）")


# ---------- 安装 ----------
def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def read_current():
    try:
        with open(updates_dir("current.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def write_current(data):
    os.makedirs(updates_dir(), exist_ok=True)
    tmp = updates_dir("current.json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, updates_dir("current.json"))


def install_code(info, path):
    """登记新代码包：下次启动由启动器加载。旧包只留最近 KEEP_CODE 个。"""
    write_current({"version": info.version, "file": os.path.basename(path), "sha256": info.sha256,
                   "shell": info.shell, "boots": 0, "bad": False, "installed": time.strftime("%Y-%m-%d %H:%M:%S")})
    zips = sorted((p for p in os.listdir(updates_dir()) if p.startswith("msz-code-") and p.endswith(".zip")),
                  key=lambda p: os.path.getmtime(updates_dir(p)), reverse=True)
    for old in zips[KEEP_CODE:]:
        try:
            os.remove(updates_dir(old))
        except OSError:
            pass


def mark_healthy():
    """新代码已正常跑起来：清零启动计数（启动器连续 3 次没等到这一步就退回内置代码）。"""
    cur = read_current()
    if cur and os.environ.get("MSZ_CODE_VERSION") == cur.get("version") and cur.get("boots"):
        cur["boots"] = 0
        write_current(cur)


def is_frozen():
    return bool(getattr(sys, "frozen", False))


def swap_exe(new_path):
    """把下载好的新 exe 换到正在运行的 exe 的位置。返回 .old 路径，失败时恢复原状并抛异常。"""
    exe = sys.executable
    old = exe + ".old"
    if os.path.exists(old):
        os.remove(old)  # 上次留下的；删不掉说明旧进程还在跑，直接报错
    os.replace(exe, old)
    try:
        shutil.move(new_path, exe)
    except Exception:
        os.replace(old, exe)
        raise
    return old


def undo_swap(old):
    exe = sys.executable
    try:
        if os.path.exists(exe):
            os.remove(exe)
    except OSError:
        pass
    os.replace(old, exe)


def cleanup_after_swap():
    """启动时删掉上次换下来的 .old。打包版的旧程序是「启动器 + 子进程」两层，子进程退出后启动器
    还要再占用 .old 片刻，所以在后台每秒试一次、最多 60 秒；还删不掉就留到下次启动。"""
    if not is_frozen():
        return
    old = sys.executable + ".old"
    if not os.path.exists(old):
        return

    def work():
        for _ in range(60):
            try:
                os.remove(old)
                return
            except FileNotFoundError:
                return
            except OSError:
                time.sleep(1)

    import threading
    threading.Thread(target=work, daemon=True).start()


def ack_path(pid):
    return updates_dir(f"restart-ack-{pid}")


def restart(extra_args=(), wait_ack=20.0):
    """启动新进程接班（它会先等本进程退出再接管）。新进程写了回执才返回 True。"""
    os.makedirs(updates_dir(), exist_ok=True)
    ack = ack_path(os.getpid())
    try:
        os.remove(ack)
    except OSError:
        pass
    if is_frozen():
        cmd = [sys.executable]
    else:
        cmd = [sys.executable, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "app.py")]
    cmd += list(extra_args) + ["--wait-pid", str(os.getpid()), "--updated-from", VERSION]
    flags = 0x00000200 | 0x08000000  # CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW
    # 打包版启动自己时，必须让新进程当成全新启动：否则它会继承 PyInstaller 的内部环境变量，
    # 直接用旧进程解压出来的临时文件夹（换 exe 后就是用旧 exe 的库跑新程序），旧进程也因为
    # 临时文件夹被占着而退不掉、.old 删不掉（2026-10-14 打包版测试发现）。
    env = {k: v for k, v in os.environ.items() if not k.startswith(("_PYI_", "_MEIPASS"))}
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    subprocess.Popen(cmd, cwd=C.app_dir(), close_fds=True, creationflags=flags, env=env)
    deadline = time.time() + wait_ack
    while time.time() < deadline:
        if os.path.exists(ack):
            try:
                os.remove(ack)
            except OSError:
                pass
            return True
        time.sleep(0.1)
    return False


def blocked_reason(now, open_at, busy_job):
    """现在能不能重启。返回空串表示可以，否则返回原因。"""
    if busy_job in ("once", "test"):
        return "正在抢订或测试填表，结束后再重启"
    if busy_job == "daemon" and open_at is not None:
        gap = (open_at - now).total_seconds()
        if 0 <= gap < 900:
            return f"离 {open_at:%H:%M} 开抢不到 15 分钟，等 {open_at + timedelta(minutes=5):%H:%M} 抢完再重启"
        if -300 < gap < 0:
            return f"正在抢 {open_at:%H:%M} 这一轮，等 {open_at + timedelta(minutes=5):%H:%M} 再重启"
    return ""
