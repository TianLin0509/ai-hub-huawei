"""程序放在含中文的目录里时，Qt 找不到自己的平台插件，会弹出一个看不见的报错框卡死。
在创建 QApplication 之前显式告诉它插件位置。"""
import os
import sys


def fix_plugin_path():
    try:
        import PyQt5
    except ImportError:
        return
    roots = [os.path.join(os.path.dirname(PyQt5.__file__), "Qt5", "plugins"),
             os.path.join(os.path.dirname(PyQt5.__file__), "Qt", "plugins")]
    if getattr(sys, "frozen", False):
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
        roots = [os.path.join(base, "PyQt5", "Qt5", "plugins"), os.path.join(base, "PyQt5", "Qt", "plugins")] + roots
    for r in roots:
        if os.path.isdir(os.path.join(r, "platforms")):
            os.environ["QT_PLUGIN_PATH"] = r
            os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = os.path.join(r, "platforms")
            return
