"""生成分享包：只放程序本身和一页使用说明。

程序文件夹里的 browser_profile 就是你的 WeLink 登录状态（等同于登录凭据），config.json 里有你的
会议室和主题，booking_history.json、screenshots、logs 里有你的预定记录——这些都不能跟着发出去。
所以分享包不打包文件夹，只从零拼出两个文件，打包后再核对一遍清单。
"""
import os
import sys
import time
import zipfile

from . import config as C

ALLOWED = {"秘书终结者.exe", "使用说明.txt"}

README = """秘书终结者 v{version} · 使用说明

秘书终结者每天 12:00 自动在 WeLink 上抢下周同一天的会议室。

第一次使用
1. 把 秘书终结者.exe 放到一个固定的文件夹里（比如 D:\\秘书终结者\\），双击打开。
   程序会在旁边生成自己的配置和登录资料，以后别挪动这个文件夹。
2. 总览 →「登录 / 检查登录」，在弹出的浏览器里登录一次 WeLink，登录成功会自动关闭，之后会记住。
3. 抢订计划：填会议主题、开始时间、时长；在「优先会议室」里点「从页面读取」，勾选你常用的几间，
   或者手动输入会议室全名（要和页面上一字不差）。按从上到下的顺序抢。
4. 总览 →「测试填表（不提交）」：走一遍但不点预定。看运行日志有没有黄色警告，
   screenshots 文件夹里的截图选的时间和会议室对不对。
5. 没问题就点「启动守护」。关掉窗口会收到右下角托盘里继续运行；可在设置里勾选开机自动启动。

更新
有新版本时左下角「软件更新」会出现红点，点开按提示更新即可；平时只下载几十 KB 的程序代码。
程序只接受发布者签名过的更新。

注意
- 程序旁边的 browser_profile 文件夹就是你的 WeLink 登录状态，不要把它（或整个程序文件夹）发给别人。
  要分享给别人，用「设置 → 生成分享包」。
- 抢到了却不用，请及时在 WeLink 里取消，把会议室让给同事。
- 和同事抢同一间会议室时只有一个人能抢到，最好各自排不同的优先会议室。
- 「会后动作」依赖公司内部工具 welink-cli，没有装也不影响抢订。
"""


def _exe():
    if getattr(sys, "frozen", False):
        return sys.executable
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "dist", "秘书终结者.exe")
    if not os.path.isfile(p):
        raise RuntimeError("源码运行时找不到 dist\\秘书终结者.exe，请先打包")
    return p


def make_package(out_dir=None):
    out_dir = out_dir or C.path("分享")
    os.makedirs(out_dir, exist_ok=True)
    dest = os.path.join(out_dir, f"{time.strftime('%Y%m%d')}-秘书终结者-v{C.VERSION}-分享.zip")
    tmp = dest + ".part"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(_exe(), "秘书终结者.exe")
        z.writestr("使用说明.txt", README.format(version=C.VERSION).replace("\n", "\r\n").encode("utf-8-sig"))
    with zipfile.ZipFile(tmp) as z:
        names = set(z.namelist())
        bad = z.testzip()
    if names != ALLOWED or bad:
        os.remove(tmp)
        raise RuntimeError(f"分享包内容不对：{sorted(names)}")
    os.replace(tmp, dest)
    return dest
